import { internalData } from "../Internal Applicant/internalData";
import { contractData } from "../Contracting Applicant/contractData";

export const allApplicantData = [...internalData, ...contractData];
